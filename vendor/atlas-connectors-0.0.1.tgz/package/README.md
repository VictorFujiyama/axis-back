# @atlas/connectors

> Phase 12.2 — the **Connector Bridge SDK**. Every app that connects to Atlas
> as a connector speaks this contract: one envelope, one HMAC scheme, one
> manifest. Internal-monorepo apps import via the workspace alias; external
> repos install per the distribution channel chosen in [12.2.06b].

## What's here

The minimal scaffold ([12.2.06]). Subsequent P0b tasks fill in:

| Task | File | Surface |
|---|---|---|
| `[12.2.07]` | `src/envelope.ts` | `ConnectorEvent` type + Zod validator |
| `[12.2.08]` | `src/manifest.ts` | `ConnectorManifest` type + drift-check map |
| `[12.2.09]` | `src/auth.ts` | HMAC sign/verify with signed `X-Atlas-Org-Id` |
| `[12.2.10]` | `src/client.ts` | `AtlasConnector` outbox client + retry |
| `[12.2.53]` | `src/subscriber.ts` | App-side inbound handler (Atlas → app events) |

## Two pillars, one contract

```
ConnectorManifest {
  app: string
  schemaVersion: string
  surface?:  { type, entrypoint, authBridge }      // the iframe Atlas embeds
  memory:    { kinds, promotableKinds, driftCheckTools }  // Pillar 1 — REQUIRED
  action?:   { api?, mcp?, harness? }              // Pillar 2 — OPTIONAL, any subset
}
```

- **Pillar 1 (afferent — memory)**: the app emits events to
  `POST /api/connectors/<app>/events`. Atlas indexes them as episodic memory
  and promotes the durable ones into curated entries.
- **Pillar 2 (efferent — action)**: Atlas's connector action-agent delegates
  intent to the app via API / MCP / harness tiers. In v1, MCP + harness ship;
  API is reserved for v2.

See `docs/spec/atlas-phase-12.2-spec.md` for the full architecture; see
`docs/spec/atlas-phase-12.2-roadmap.md` for the task plan.

## Scripts

```bash
pnpm --filter @atlas/connectors typecheck
pnpm --filter @atlas/connectors test
```
