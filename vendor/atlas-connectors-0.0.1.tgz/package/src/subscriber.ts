/**
 * [12.2.53] AtlasSubscriber — server-side helper for apps that receive
 * Atlas outbound events.
 *
 * Mirror image of [12.2.10]'s `AtlasConnector` (which sends INTO Atlas).
 * Apps mount one endpoint (typically `POST /atlas-events`) and run the
 * incoming request through `subscriber.handle(req)` to:
 *   1. Verify the HMAC signature using the same `verifyRequest` helper
 *      Atlas uses on the inbound side (symmetric contract).
 *   2. Parse + validate the envelope.
 *   3. Dispatch to user-provided `onAtlasActivity` hook.
 *
 * Returns a `{status, body}` pair the user wires into their framework
 * (Fastify, Express, Next.js Route Handler — anything). Adapters are
 * not bundled — the API is small enough that an app's framework glue
 * stays in app code.
 *
 * Contract:
 *   - 200 → handled; the user hook ran without throwing.
 *   - 401 → signature invalid or missing.
 *   - 400 → envelope malformed.
 *   - 5xx → user hook threw; subscriber re-throws so the framework
 *     can log + return its own 5xx.
 */
import {
  ORG_ID_HEADER,
  SIGNATURE_HEADER,
  verifyRequest,
  type VerifyFailReason,
} from './auth.js';
import { parseConnectorEvent, type ConnectorEvent } from './envelope.js';

export interface HandleRequestInput {
  /** Raw request body as a string (UTF-8). MUST be the exact bytes the
   *  signer used — do NOT call `JSON.parse(...).toString(...)` on it.
   *  Most frameworks expose this via a raw-body parser hook. */
  rawBody: string;
  /** Case-insensitive header accessor. Both Fastify (`request.headers`)
   *  and the Web `Headers` API are compatible — pass `.get` style. */
  headers: {
    get(name: string): string | null | undefined;
  };
}

export interface HandleSuccess {
  status: 200;
  body: { ok: true; event_id: string };
  event: ConnectorEvent;
}
export interface HandleFailure {
  status: 400 | 401;
  body: { ok: false; error: string };
}
export type HandleResult = HandleSuccess | HandleFailure;

export interface AtlasSubscriberOpts {
  /** HMAC secret shared with Atlas. Same secret Atlas signs outbound with. */
  hmacSecret: string;
  /** Called on every verified + parsed event. Throwing rethrows up. */
  onAtlasActivity: (event: ConnectorEvent) => Promise<void> | void;
  /** Optional skew tolerance override (default uses auth.ts SKEW_TOLERANCE_SEC). */
  skewToleranceSec?: number;
}

export class AtlasSubscriber {
  constructor(private readonly opts: AtlasSubscriberOpts) {}

  /**
   * Verify, parse, dispatch. Returns a `{status, body}` pair the
   * framework adapter sends back as the HTTP response.
   *
   * On hook throw: rethrows so framework logging captures the error;
   * the framework can then return its own 5xx + the event_id for retry.
   */
  async handle(input: HandleRequestInput): Promise<HandleResult> {
    // (1) Verify signature.
    const signature = input.headers.get(SIGNATURE_HEADER);
    const orgIdHeader = input.headers.get(ORG_ID_HEADER);
    const verifyResult = verifyRequest(
      input.rawBody,
      signature ?? null,
      orgIdHeader ?? null,
      this.opts.hmacSecret,
    );
    if (!verifyResult.ok) {
      return {
        status: 401,
        body: { ok: false, error: `signature: ${verifyResult.reason}` },
      };
    }

    // (2) Parse envelope.
    let json: unknown;
    try {
      json = JSON.parse(input.rawBody);
    } catch {
      return { status: 400, body: { ok: false, error: 'envelope: invalid JSON' } };
    }
    const parsed = parseConnectorEvent(json);
    if (!parsed.ok) {
      return {
        status: 400,
        body: {
          ok: false,
          error: `envelope: ${parsed.error.issues[0]?.message ?? 'invalid'}`,
        },
      };
    }

    // (3) Cross-check the signed orgId header matches envelope.org_id.
    if (parsed.event.org_id !== verifyResult.orgId) {
      return {
        status: 400,
        body: {
          ok: false,
          error: `envelope: org_id mismatch (header=${verifyResult.orgId}, body=${parsed.event.org_id})`,
        },
      };
    }

    // (4) Dispatch. Throws bubble — framework returns 5xx.
    await this.opts.onAtlasActivity(parsed.event);

    return {
      status: 200,
      body: { ok: true, event_id: parsed.event.event_id },
      event: parsed.event,
    };
  }
}

/** Failure reasons surfaced to callers (in addition to verifyRequest's set). */
export type SubscriberFailReason =
  | VerifyFailReason
  | 'envelope-invalid-json'
  | 'envelope-malformed'
  | 'org-id-mismatch';
