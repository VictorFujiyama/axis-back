import { z } from 'zod';

/**
 * [12.2.08] ConnectorManifest — the standard bridge contract.
 *
 * Every connected app (axis-back today, future CRM/calendar/finance
 * tomorrow) ships a manifest that Atlas reads at install time. The
 * manifest declares: the app's Surface (the iframe Atlas embeds),
 * Pillar 1 (Memory — what kinds of events the app emits, which kinds
 * promote to durable memory, which MCP tool answers a drift-check
 * probe per kind), and Pillar 2 (Action — typed API + MCP + harness
 * tiers; transactional intents that must stay on A/B).
 *
 * Three shapes are valid:
 *   - memory-only        → Atlas knows everything, cannot act
 *   - memory + action.harness → works day one, zero action engineering
 *   - memory + action.{mcp,api} → typed actions, no UI fallback
 *
 * Locked decisions (spec §9 + roadmap [12.2.08]):
 *   - `action.api` is RESERVED for v2 (manifest field accepts the value
 *     for forward-compat; no runtime code consumes it in 12.2).
 *   - `memory.driftCheckTools` maps a `kind` → MCP tool name; the
 *     drift-check cron ([12.2.32]) calls this tool with the entry's
 *     `source_ref.id` to verify the source still has the record.
 *
 * Refinements enforced:
 *   - `promotableKinds ⊆ kinds` (can't promote a kind you don't emit)
 *   - keys of `driftCheckTools ⊆ kinds` (can't drift-check an absent kind)
 */

// ────────────────────────────────────────────────────────────────────────────
// Surface — the iframe the human + Tier C harness drive

export const SurfaceTypeSchema = z.enum(['web-iframe', 'none']);
export type SurfaceType = z.infer<typeof SurfaceTypeSchema>;

export const SurfaceAuthBridgeSchema = z.enum(['sso-jwt']);
export type SurfaceAuthBridge = z.infer<typeof SurfaceAuthBridgeSchema>;

export const ConnectorSurfaceSchema = z.object({
  type: SurfaceTypeSchema,
  /** URL Atlas embeds via iframe. Empty/N-A for `type: 'none'`. */
  entrypoint: z.string(),
  /** How the human (and the [12.2.44] harness) authenticate into the surface. */
  authBridge: SurfaceAuthBridgeSchema,
});
export type ConnectorSurface = z.infer<typeof ConnectorSurfaceSchema>;

// ────────────────────────────────────────────────────────────────────────────
// Action — Pillar 2's tiered toolbelt

/**
 * Tier A — typed HTTP API. RESERVED for v2 — manifest field accepts the
 * value but no runtime code reads it in 12.2. Kept here so apps writing
 * forward-looking manifests don't have to refactor when v2 lands.
 */
export const ConnectorApiSpecSchema = z
  .object({
    baseUrl: z.string().url(),
    operations: z.array(z.string()),
  })
  .passthrough();
export type ConnectorApiSpec = z.infer<typeof ConnectorApiSpecSchema>;

/**
 * Tier B — MCP. Reference to a row in the `mcp_servers` table (per-org
 * registered server). The connector action-agent in [12.2.36] filters
 * the global tool registry to `mcp_<orgShort>_<app>_*` and surfaces
 * those tools to the agent.
 */
export const ConnectorMcpServerRefSchema = z.object({
  /** Server `name` column in `mcp_servers` — must match how it's registered there. */
  name: z.string().min(1),
});
export type ConnectorMcpServerRef = z.infer<typeof ConnectorMcpServerRefSchema>;

/**
 * Tier C — harness on the Surface. Driven by Browser Use Cloud in
 * [12.2.43b]/[12.2.44]. `drives: 'surface'` is the only valid form in
 * v1 (no headless-CLI harness etc.).
 */
export const ConnectorHarnessSchema = z.object({
  drives: z.literal('surface'),
});
export type ConnectorHarness = z.infer<typeof ConnectorHarnessSchema>;

export const ConnectorActionSchema = z.object({
  /** RESERVED for v2 — set ignored at runtime in 12.2. */
  api: ConnectorApiSpecSchema.optional(),
  mcp: ConnectorMcpServerRefSchema.optional(),
  harness: ConnectorHarnessSchema.optional(),
  /**
   * Intent strings (matched substring-style by [12.2.37]'s gate) that
   * MUST NOT route to the Tier C harness. Money movement, deletes,
   * irreversible state. Empty/undefined = no transactional restrictions.
   */
  transactionalActions: z.array(z.string()).default([]),
});
export type ConnectorAction = z.infer<typeof ConnectorActionSchema>;

// ────────────────────────────────────────────────────────────────────────────
// Memory — Pillar 1

export const ConnectorMemorySchema = z.object({
  /** All event kinds the app emits — open string per the envelope's forward-compat policy. */
  kinds: z.array(z.string().min(1)).min(1),
  /**
   * Subset of `kinds` that triggers the [12.2.27] promotion gate. The
   * curator only runs for events whose kind is in this list — cheap
   * deterministic filter before any LLM cost.
   */
  promotableKinds: z.array(z.string().min(1)).default([]),
  /**
   * Map `kind` → MCP tool name. [12.2.32]'s drift-check cron calls this
   * tool with the entry's `source_ref.id` to verify the source still has
   * the record (404 → mark divergent, alert at >5% sample divergence).
   * Keys must be subset of `kinds`.
   */
  driftCheckTools: z.record(z.string().min(1)).default({}),
});
export type ConnectorMemory = z.infer<typeof ConnectorMemorySchema>;

// ────────────────────────────────────────────────────────────────────────────
// Manifest

export const ConnectorManifestSchema = z
  .object({
    /** App slug — must match `connectors.app` column. Lowercase ascii + dash recommended. */
    app: z
      .string()
      .min(1)
      .regex(/^[a-z][a-z0-9-]*$/, 'app must be lowercase-ascii-and-dash slug'),
    /** SemVer for the manifest format itself — bumps when manifest schema evolves. */
    schemaVersion: z.string().min(1),
    surface: ConnectorSurfaceSchema.optional(),
    memory: ConnectorMemorySchema,
    action: ConnectorActionSchema.optional(),
  })
  .superRefine((manifest, ctx) => {
    // promotableKinds ⊆ kinds
    const kinds = new Set(manifest.memory.kinds);
    for (const k of manifest.memory.promotableKinds) {
      if (!kinds.has(k)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `memory.promotableKinds contains '${k}' which is not in memory.kinds`,
          path: ['memory', 'promotableKinds'],
        });
      }
    }
    // driftCheckTools keys ⊆ kinds
    for (const k of Object.keys(manifest.memory.driftCheckTools)) {
      if (!kinds.has(k)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `memory.driftCheckTools has key '${k}' which is not in memory.kinds`,
          path: ['memory', 'driftCheckTools'],
        });
      }
    }
  });

export type ConnectorManifest = z.infer<typeof ConnectorManifestSchema>;

export type ParseConnectorManifestResult =
  | { ok: true; manifest: ConnectorManifest }
  | { ok: false; error: z.ZodError };

export function parseConnectorManifest(input: unknown): ParseConnectorManifestResult {
  const result = ConnectorManifestSchema.safeParse(input);
  if (result.success) return { ok: true, manifest: result.data };
  return { ok: false, error: result.error };
}

// ────────────────────────────────────────────────────────────────────────────
// Lifecycle hook signatures (types only — implementations live in the app
// that ships the manifest, called by the bridge at the relevant moment)

/** Bridge fires before emit — app can transform/enrich the envelope. */
export type OnEventHook = (
  envelope: import('./envelope.js').ConnectorEvent,
) => Promise<import('./envelope.js').ConnectorEvent>;

/** Bridge fires when [12.2.58] backfill walks history — app paginates by cursor. */
export type OnBackfillHook = (
  cursor: string | null,
  limit: number,
) => Promise<{ events: import('./envelope.js').ConnectorEvent[]; nextCursor: string | null }>;

/** Bridge fires when Atlas emits an event toward the app ([12.2.51] outbound). */
export type OnAtlasActivityHook = (
  envelope: import('./envelope.js').ConnectorEvent,
) => Promise<void>;

/** Bridge fires before the action-agent routes an intent — app can transform. */
export type OnActionRequestHook = (intent: {
  intent: string;
  args?: unknown;
}) => Promise<{ intent: string; args?: unknown }>;
