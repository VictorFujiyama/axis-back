import test from 'node:test';
import assert from 'node:assert/strict';
import { signRequest } from '../auth.js';
import type { ConnectorEvent } from '../envelope.js';
import { AtlasSubscriber } from '../subscriber.js';

/**
 * [12.2.53] AtlasSubscriber unit tests. Pure — no HTTP framework, just
 * the {rawBody, headers} shape.
 */

const SECRET = 'unit-test-shared-secret-for-symmetric-hmac';
const ORG_ID = '00000000-0000-4000-8000-000000000001';

function buildEvent(overrides: Partial<ConnectorEvent> = {}): ConnectorEvent {
  return {
    event_id: 'atlas_test_1',
    schema_version: '1.0',
    emitted_at: new Date().toISOString(),
    app: 'atlas',
    org_id: ORG_ID,
    kind: 'memory_write',
    action: 'create',
    source_ref: { id: 'COMPANY_MEMORY.md:1234' },
    occurred_at: new Date().toISOString(),
    actors: [
      { app_user_id: 'atlas-bot', role: 'sender', hints: {} },
    ],
    participants: [],
    summary: 'test summary',
    viewable_by: { scope: 'org' },
    metadata: { atlas_initiated: true },
    ...overrides,
  };
}

function headersFromMap(map: Record<string, string>): { get(name: string): string | null } {
  return {
    get(name: string): string | null {
      const k = Object.keys(map).find((m) => m.toLowerCase() === name.toLowerCase());
      return k && map[k] !== undefined ? map[k]! : null;
    },
  };
}

function buildSignedRequest(event: ConnectorEvent, secret = SECRET) {
  const rawBody = JSON.stringify(event);
  const { signature, orgIdHeader } = signRequest(rawBody, event.org_id, secret);
  return {
    rawBody,
    headers: headersFromMap({
      'X-Atlas-Signature': signature,
      'X-Atlas-Org-Id': orgIdHeader,
    }),
  };
}

// ────────────────────────────────────────────────────────────────────

test('AtlasSubscriber — verified + parsed event dispatches', async () => {
  const received: ConnectorEvent[] = [];
  const sub = new AtlasSubscriber({
    hmacSecret: SECRET,
    onAtlasActivity: async (event) => {
      received.push(event);
    },
  });
  const event = buildEvent();
  const result = await sub.handle(buildSignedRequest(event));

  assert.equal(result.status, 200);
  assert.equal(received.length, 1);
  assert.equal(received[0]?.event_id, 'atlas_test_1');
});

test('AtlasSubscriber — forged signature → 401', async () => {
  const sub = new AtlasSubscriber({
    hmacSecret: SECRET,
    onAtlasActivity: async () => {
      throw new Error('hook should not have been called');
    },
  });
  const event = buildEvent();
  // Sign with a DIFFERENT secret
  const result = await sub.handle(buildSignedRequest(event, 'WRONG-SECRET'));
  assert.equal(result.status, 401);
  assert.match(
    (result as { body: { error: string } }).body.error,
    /signature/,
  );
});

test('AtlasSubscriber — missing signature header → 401', async () => {
  const sub = new AtlasSubscriber({
    hmacSecret: SECRET,
    onAtlasActivity: async () => undefined,
  });
  const event = buildEvent();
  const result = await sub.handle({
    rawBody: JSON.stringify(event),
    headers: headersFromMap({}),
  });
  assert.equal(result.status, 401);
});

test('AtlasSubscriber — malformed JSON body → 400', async () => {
  const sub = new AtlasSubscriber({
    hmacSecret: SECRET,
    onAtlasActivity: async () => undefined,
  });
  const rawBody = 'not json at all';
  const { signature, orgIdHeader } = signRequest(rawBody, ORG_ID, SECRET);
  const result = await sub.handle({
    rawBody,
    headers: headersFromMap({
      'X-Atlas-Signature': signature,
      'X-Atlas-Org-Id': orgIdHeader,
    }),
  });
  assert.equal(result.status, 400);
});

test('AtlasSubscriber — org_id mismatch (header vs body) → 400', async () => {
  const sub = new AtlasSubscriber({
    hmacSecret: SECRET,
    onAtlasActivity: async () => undefined,
  });
  const event = buildEvent({ org_id: '99999999-9999-4999-8999-999999999999' });
  const rawBody = JSON.stringify(event);
  // Sign using a DIFFERENT org_id than what's in the body.
  const { signature, orgIdHeader } = signRequest(rawBody, ORG_ID, SECRET);
  const result = await sub.handle({
    rawBody,
    headers: headersFromMap({
      'X-Atlas-Signature': signature,
      'X-Atlas-Org-Id': orgIdHeader,
    }),
  });
  assert.equal(result.status, 400);
  assert.match(
    (result as { body: { error: string } }).body.error,
    /org_id mismatch/,
  );
});

test('AtlasSubscriber — hook throw propagates (framework returns 5xx)', async () => {
  const sub = new AtlasSubscriber({
    hmacSecret: SECRET,
    onAtlasActivity: async () => {
      throw new Error('app-side dispatch failed');
    },
  });
  const event = buildEvent();
  await assert.rejects(
    () => sub.handle(buildSignedRequest(event)),
    /app-side dispatch failed/,
  );
});
