import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import {
  ORG_ID_HEADER,
  SIGNATURE_HEADER,
  SKEW_TOLERANCE_SEC,
  signRequest,
  verifyRequest,
} from '../auth.js';

const SECRET = 'test-secret-do-not-use-anywhere-real';
const PREV_SECRET = 'previous-secret-also-test-only';
const ORG_ID = '11111111-1111-4111-8111-111111111111';
const BODY = JSON.stringify({ event_id: 'evt_001', kind: 'conversation_turn' });

test('happy path — sign + verify round-trip', () => {
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, SECRET);
  const result = verifyRequest(BODY, signature, orgIdHeader, SECRET);
  assert.equal(result.ok, true);
  if (result.ok) assert.equal(result.orgId, ORG_ID);
});

test('header constants — lowercase canonical names', () => {
  assert.equal(SIGNATURE_HEADER, 'x-atlas-signature');
  assert.equal(ORG_ID_HEADER, 'x-atlas-org-id');
});

test('missing signature header → 401-class reason', () => {
  const r = verifyRequest(BODY, null, ORG_ID, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'missing-signature-header');
});

test('missing org-id header → 401-class reason', () => {
  const { signature } = signRequest(BODY, ORG_ID, SECRET);
  const r = verifyRequest(BODY, signature, null, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'missing-org-id-header');
});

test('forged signature with wrong secret rejected', () => {
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, 'wrong-secret');
  const r = verifyRequest(BODY, signature, orgIdHeader, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'invalid-signature');
});

test('tampered body invalidates signature', () => {
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, SECRET);
  const tampered = BODY + ' MALICIOUS';
  const r = verifyRequest(tampered, signature, orgIdHeader, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'invalid-signature');
});

test('tampered X-Atlas-Org-Id invalidates signature (the load-bearing test for fix #6)', () => {
  const { signature } = signRequest(BODY, ORG_ID, SECRET);
  const otherOrg = '22222222-2222-4222-8222-222222222222';
  // Attacker provides someone else's org-id header but the body's signature
  // was computed against the legitimate org. Receiver verifies against the
  // header's claimed org-id → HMAC mismatch.
  const r = verifyRequest(BODY, signature, otherOrg, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'invalid-signature');
});

test('timestamp skew >300s rejected (past)', () => {
  const longAgo = Date.now() - (SKEW_TOLERANCE_SEC + 5) * 1000;
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, SECRET, longAgo);
  const r = verifyRequest(BODY, signature, orgIdHeader, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'timestamp-skew');
});

test('timestamp skew >300s rejected (future)', () => {
  const farFuture = Date.now() + (SKEW_TOLERANCE_SEC + 5) * 1000;
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, SECRET, farFuture);
  const r = verifyRequest(BODY, signature, orgIdHeader, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'timestamp-skew');
});

test('rotation window — signed with prev secret, current+prev both pass', () => {
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, PREV_SECRET);
  const r = verifyRequest(BODY, signature, orgIdHeader, SECRET, PREV_SECRET);
  assert.equal(r.ok, true);
});

test('rotation window — signed with current secret still passes when prev present', () => {
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, SECRET);
  const r = verifyRequest(BODY, signature, orgIdHeader, SECRET, PREV_SECRET);
  assert.equal(r.ok, true);
});

test('rotation window OFF — signed with prev secret, prev not provided → reject', () => {
  const { signature, orgIdHeader } = signRequest(BODY, ORG_ID, PREV_SECRET);
  const r = verifyRequest(BODY, signature, orgIdHeader, SECRET);
  assert.equal(r.ok, false);
});

test('malformed signature header (missing t=) → malformed reason', () => {
  const r = verifyRequest(BODY, 'v1=abc123', ORG_ID, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'malformed-signature-header');
});

test('malformed signature header (missing v1=) → malformed reason', () => {
  const r = verifyRequest(BODY, 't=1234567890', ORG_ID, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'malformed-signature-header');
});

test('malformed timestamp (non-numeric) → malformed-timestamp', () => {
  const r = verifyRequest(BODY, 't=abc,v1=deadbeef', ORG_ID, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'malformed-timestamp');
});

test('timing-safe compare — sig of wrong hex length still returns invalid-signature without throwing', () => {
  const { orgIdHeader } = signRequest(BODY, ORG_ID, SECRET);
  const shortSig = `t=${Math.floor(Date.now() / 1000)},v1=ab`;
  const r = verifyRequest(BODY, shortSig, orgIdHeader, SECRET);
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.reason, 'invalid-signature');
});
