import { strict as assert } from 'node:assert';
import { randomUUID } from 'node:crypto';
import { test } from 'node:test';
import {
  ConnectorEventSchema,
  type ConnectorEvent,
  parseConnectorEvent,
} from '../envelope.js';

/** Builder for a valid envelope — tests start from this and tweak. */
function validEnvelope(overrides: Partial<ConnectorEvent> = {}): unknown {
  return {
    event_id: `evt_${randomUUID()}`,
    schema_version: '1.0',
    emitted_at: '2026-05-15T10:00:00Z',
    app: 'messaging',
    app_version: '2.4.1',
    org_id: '11111111-1111-4111-8111-111111111111',
    kind: 'conversation_turn',
    action: 'create',
    source_ref: {
      id: 'msg_abc',
      parent_id: 'conv_def',
      url: 'https://msg.app/c/conv_def#msg_abc',
    },
    occurred_at: '2026-05-15T09:59:58Z',
    actors: [
      {
        app_user_id: 'u_42',
        role: 'sender',
        hints: { email: 'joao@folego.com' },
      },
    ],
    participants: [{ app_user_id: 'u_42', hints: { email: 'joao@folego.com' } }],
    summary: "João sent: 'pode confirmar a renovação até sexta?'",
    embedding_text: 'longer-content for embedding...',
    viewable_by: { scope: 'participants' },
    metadata: { channel: 'whatsapp', is_ai_handoff: false },
    ...overrides,
  };
}

test('parses a complete valid envelope', () => {
  const result = parseConnectorEvent(validEnvelope());
  assert.ok(result.ok, 'should parse successfully');
  if (!result.ok) return;
  assert.equal(result.event.app, 'messaging');
  assert.equal(result.event.kind, 'conversation_turn');
  assert.equal(result.event.action, 'create');
  assert.equal(result.event.actors.length, 1);
  assert.equal(result.event.actors[0]!.app_user_id, 'u_42');
});

test('round-trip — parse → stringify → parse preserves shape', () => {
  const original = validEnvelope() as ConnectorEvent;
  const first = parseConnectorEvent(original);
  assert.ok(first.ok);
  const json = JSON.stringify(first.ok ? first.event : null);
  const second = parseConnectorEvent(JSON.parse(json));
  assert.ok(second.ok);
  assert.deepEqual(first.ok ? first.event : null, second.ok ? second.event : null);
});

test('missing event_id → ZodError', () => {
  const env = validEnvelope();
  delete (env as Record<string, unknown>).event_id;
  const result = parseConnectorEvent(env);
  assert.equal(result.ok, false);
  if (!result.ok) {
    const issues = result.error.issues;
    assert.ok(issues.some((i) => i.path.includes('event_id')));
  }
});

test('missing org_id → ZodError', () => {
  const env = validEnvelope();
  delete (env as Record<string, unknown>).org_id;
  const result = parseConnectorEvent(env);
  assert.equal(result.ok, false);
});

test('invalid org_id (not uuid) → ZodError', () => {
  const result = parseConnectorEvent(validEnvelope({ org_id: 'not-a-uuid' }));
  assert.equal(result.ok, false);
});

test('unknown `kind` parses (forward-compat — Atlas drops unknown kinds, does NOT reject)', () => {
  const result = parseConnectorEvent(
    validEnvelope({ kind: 'a_brand_new_kind_we_dont_know_yet' as ConnectorEvent['kind'] }),
  );
  assert.ok(result.ok, 'unknown kinds must parse for forward-compat per Phase 12 §12.1.02');
  if (result.ok) {
    assert.equal(result.event.kind, 'a_brand_new_kind_we_dont_know_yet');
  }
});

test('invalid `action` value → ZodError', () => {
  const result = parseConnectorEvent(
    validEnvelope({ action: 'destroyed' as ConnectorEvent['action'] }),
  );
  assert.equal(result.ok, false);
});

test('embedding_text: null is valid (explicit skip per §12.1.06)', () => {
  const result = parseConnectorEvent(validEnvelope({ embedding_text: null }));
  assert.ok(result.ok);
  if (result.ok) {
    assert.equal(result.event.embedding_text, null);
  }
});

test('embedding_text omitted is valid (also skip-embed)', () => {
  const env = validEnvelope();
  delete (env as Record<string, unknown>).embedding_text;
  const result = parseConnectorEvent(env);
  assert.ok(result.ok);
  if (result.ok) {
    assert.equal(result.event.embedding_text, undefined);
  }
});

test('actors / participants default to empty arrays when omitted', () => {
  const env = validEnvelope();
  delete (env as Record<string, unknown>).actors;
  delete (env as Record<string, unknown>).participants;
  const result = parseConnectorEvent(env);
  assert.ok(result.ok);
  if (result.ok) {
    assert.deepEqual(result.event.actors, []);
    assert.deepEqual(result.event.participants, []);
  }
});

test('metadata defaults to empty object when omitted', () => {
  const env = validEnvelope();
  delete (env as Record<string, unknown>).metadata;
  const result = parseConnectorEvent(env);
  assert.ok(result.ok);
  if (result.ok) {
    assert.deepEqual(result.event.metadata, {});
  }
});

test('viewable_by.scope is required', () => {
  const env = validEnvelope();
  (env as Record<string, unknown>).viewable_by = {};
  const result = parseConnectorEvent(env);
  assert.equal(result.ok, false);
});

test('actor without app_user_id → ZodError', () => {
  const result = parseConnectorEvent(
    validEnvelope({ actors: [{ role: 'sender' } as ConnectorEvent['actors'][number]] }),
  );
  assert.equal(result.ok, false);
});

test('emitted_at must be ISO 8601 with offset', () => {
  // No offset (missing Z or ±hh:mm) → reject per Zod's datetime({offset: true}).
  const result = parseConnectorEvent(validEnvelope({ emitted_at: '2026-05-15 10:00:00' }));
  assert.equal(result.ok, false);
});

test('actor hints accepts arbitrary keys (catchall) — atlas_user_id stamped by emitter [12.2.39]', () => {
  const result = parseConnectorEvent(
    validEnvelope({
      actors: [
        {
          app_user_id: 'atlas-bot-xyz',
          role: 'sender',
          hints: {
            email: 'atlas-bot@atlas.internal',
            atlas_user_id: 'clerk_user_abc',
            // arbitrary extra key — catchall keeps it for app-specific signals
            custom_attribute: 'preserved',
          },
        },
      ],
    }),
  );
  assert.ok(result.ok);
  if (result.ok) {
    const hints = result.event.actors[0]!.hints as Record<string, unknown>;
    assert.equal(hints.atlas_user_id, 'clerk_user_abc');
    assert.equal(hints.custom_attribute, 'preserved');
  }
});

test('throws-style parse via .parse() works too (for callers that prefer exceptions)', () => {
  // Sanity check that ConnectorEventSchema.parse() throws on invalid input.
  const env = validEnvelope();
  delete (env as Record<string, unknown>).event_id;
  assert.throws(() => ConnectorEventSchema.parse(env));
});
