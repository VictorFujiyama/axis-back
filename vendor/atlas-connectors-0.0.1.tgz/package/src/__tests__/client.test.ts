import { strict as assert } from 'node:assert';
import { randomUUID } from 'node:crypto';
import { test } from 'node:test';
import { AtlasConnector, ConnectorEmitFailedError, type QueueAdapter } from '../client.js';
import type { ConnectorEvent } from '../envelope.js';

const ORG_ID = '11111111-1111-4111-8111-111111111111';
const SECRET = 'test-secret';
const BASE = 'https://atlas.test';

function event(over: Partial<ConnectorEvent> = {}): ConnectorEvent {
  return {
    event_id: `evt_${randomUUID()}`,
    schema_version: '1.0',
    emitted_at: new Date().toISOString(),
    app: 'messaging',
    org_id: ORG_ID,
    kind: 'conversation_turn',
    action: 'create',
    source_ref: { id: 'msg_001' },
    occurred_at: new Date().toISOString(),
    actors: [],
    participants: [],
    summary: 'hello',
    viewable_by: { scope: 'org' },
    metadata: {},
    ...over,
  } as ConnectorEvent;
}

interface FetchCall {
  url: string;
  method?: string;
  headers: Record<string, string>;
  body: string;
}

function mockFetch(
  responder: (call: FetchCall) => { status: number } | Error,
): { fetchImpl: typeof globalThis.fetch; calls: FetchCall[] } {
  const calls: FetchCall[] = [];
  const fetchImpl: typeof globalThis.fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : (input as URL).toString();
    const headers: Record<string, string> = {};
    const initHeaders = init?.headers;
    if (initHeaders) {
      if (initHeaders instanceof Headers) {
        initHeaders.forEach((v, k) => {
          headers[k.toLowerCase()] = v;
        });
      } else if (Array.isArray(initHeaders)) {
        for (const pair of initHeaders) {
          const [k, v] = pair;
          if (typeof k === 'string' && typeof v === 'string') {
            headers[k.toLowerCase()] = v;
          }
        }
      } else {
        for (const [k, v] of Object.entries(initHeaders)) {
          if (typeof v === 'string') headers[k.toLowerCase()] = v;
        }
      }
    }
    const call: FetchCall = {
      url,
      ...(init?.method ? { method: init.method } : {}),
      headers,
      body: typeof init?.body === 'string' ? init.body : '',
    };
    calls.push(call);
    const result = responder(call);
    if (result instanceof Error) throw result;
    return new Response(null, { status: result.status }) as unknown as Response;
  };
  return { fetchImpl, calls };
}

test('happy path — single emit posts signed event, 202 response', async () => {
  const { fetchImpl, calls } = mockFetch(() => ({ status: 202 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
  });
  await c.emit(event());

  assert.equal(calls.length, 1);
  const [call] = calls;
  assert.equal(call!.url, `${BASE}/api/connectors/messaging/events`);
  assert.equal(call!.method, 'POST');
  assert.equal(call!.headers['content-type'], 'application/json');
  assert.match(call!.headers['x-atlas-signature']!, /^t=\d+,v1=[0-9a-f]+$/);
  assert.equal(call!.headers['x-atlas-org-id'], ORG_ID);
});

test('5xx retries with exp backoff and eventually succeeds', async () => {
  let n = 0;
  const { fetchImpl, calls } = mockFetch(() => {
    n += 1;
    return { status: n < 3 ? 503 : 202 };
  });
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
    backoffBaseMs: 1, // speed up tests
  });
  await c.emit(event());
  assert.equal(calls.length, 3);
});

test('4xx → no retry, fails fast with ConnectorEmitFailedError', async () => {
  const { fetchImpl, calls } = mockFetch(() => ({ status: 401 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
    backoffBaseMs: 1,
  });
  let caught: unknown;
  try {
    await c.emit(event());
  } catch (err) {
    caught = err;
  }
  assert.ok(caught instanceof ConnectorEmitFailedError);
  assert.equal((caught as ConnectorEmitFailedError).lastStatus, 401);
  assert.equal(calls.length, 1, 'no retry on 4xx');
});

test('5xx exhausts retries → throws ConnectorEmitFailedError after maxAttempts', async () => {
  const { fetchImpl, calls } = mockFetch(() => ({ status: 502 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
    maxAttempts: 3,
    backoffBaseMs: 1,
  });
  let caught: unknown;
  try {
    await c.emit(event());
  } catch (err) {
    caught = err;
  }
  assert.ok(caught instanceof ConnectorEmitFailedError);
  assert.equal((caught as ConnectorEmitFailedError).attempts, 3);
  assert.equal(calls.length, 3);
});

test('network error → retryable', async () => {
  let n = 0;
  const { fetchImpl, calls } = mockFetch(() => {
    n += 1;
    if (n < 2) return new Error('ECONNRESET');
    return { status: 202 };
  });
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
    backoffBaseMs: 1,
  });
  await c.emit(event());
  assert.equal(calls.length, 2);
});

test('emitBatch — single POST with {events: [...]}', async () => {
  const { fetchImpl, calls } = mockFetch(() => ({ status: 202 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
  });
  const events = [event(), event(), event()];
  await c.emitBatch(events);

  assert.equal(calls.length, 1);
  const parsed = JSON.parse(calls[0]!.body) as { events: ConnectorEvent[] };
  assert.equal(parsed.events.length, 3);
});

test('emitBatch — empty array no-op', async () => {
  const { fetchImpl, calls } = mockFetch(() => ({ status: 202 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
  });
  await c.emitBatch([]);
  assert.equal(calls.length, 0);
});

test('emitBatch — > 1000 events throws (spec §12.2.01 cap)', async () => {
  const { fetchImpl } = mockFetch(() => ({ status: 202 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
  });
  const many = Array.from({ length: 1001 }, () => event());
  await assert.rejects(c.emitBatch(many), /exceeds 1000/);
});

test('queue adapter receives single emit and inline POST is skipped', async () => {
  const enqueued: ConnectorEvent[] = [];
  const adapter: QueueAdapter = {
    enqueue: async (e: ConnectorEvent) => {
      enqueued.push(e);
    },
  };
  const { fetchImpl, calls } = mockFetch(() => ({ status: 202 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
    queueAdapter: adapter,
  });
  await c.emit(event());
  assert.equal(enqueued.length, 1);
  assert.equal(calls.length, 0, 'inline POST skipped when adapter present');
});

test('queue adapter — emitBatch enqueues each event individually', async () => {
  const enqueued: ConnectorEvent[] = [];
  const adapter: QueueAdapter = {
    enqueue: async (e: ConnectorEvent) => {
      enqueued.push(e);
    },
  };
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    queueAdapter: adapter,
  });
  await c.emitBatch([event(), event(), event()]);
  assert.equal(enqueued.length, 3);
});

test('emitDirect bypasses adapter (used by worker after dequeue)', async () => {
  const enqueued: ConnectorEvent[] = [];
  const adapter: QueueAdapter = {
    enqueue: async (e: ConnectorEvent) => {
      enqueued.push(e);
    },
  };
  const { fetchImpl, calls } = mockFetch(() => ({ status: 202 }));
  const c = new AtlasConnector({
    atlasBaseUrl: BASE,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
    queueAdapter: adapter,
  });
  await c.emitDirect(event());
  assert.equal(enqueued.length, 0);
  assert.equal(calls.length, 1);
});

test('trailing-slash in atlasBaseUrl is normalized', async () => {
  const { fetchImpl, calls } = mockFetch(() => ({ status: 202 }));
  const c = new AtlasConnector({
    atlasBaseUrl: `${BASE}/`,
    app: 'messaging',
    orgId: ORG_ID,
    hmacSecret: SECRET,
    fetchImpl,
  });
  await c.emit(event());
  assert.equal(calls[0]!.url, `${BASE}/api/connectors/messaging/events`);
});
