import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import {
  ConnectorManifestSchema,
  type ConnectorManifest,
  parseConnectorManifest,
} from '../manifest.js';

function valid(overrides: Partial<ConnectorManifest> = {}): unknown {
  return {
    app: 'messaging',
    schemaVersion: '1.0',
    memory: {
      kinds: ['conversation_turn', 'conversation_summary', 'contact'],
      promotableKinds: ['conversation_summary'],
      driftCheckTools: { conversation_turn: 'get_thread' },
    },
    ...overrides,
  };
}

test('memory-only manifest parses', () => {
  const result = parseConnectorManifest(valid());
  assert.ok(result.ok);
  if (result.ok) {
    assert.equal(result.manifest.app, 'messaging');
    assert.equal(result.manifest.action, undefined);
    assert.equal(result.manifest.surface, undefined);
  }
});

test('memory + action.harness-only manifest parses (zero engineering on app side)', () => {
  const result = parseConnectorManifest(
    valid({
      action: { harness: { drives: 'surface' }, transactionalActions: [] },
    }),
  );
  assert.ok(result.ok);
});

test('memory + action.mcp manifest parses (Tier B only)', () => {
  const result = parseConnectorManifest(
    valid({
      action: {
        mcp: { name: 'messaging' },
        transactionalActions: ['transfer_money', 'delete_account'],
      },
    }),
  );
  assert.ok(result.ok);
  if (result.ok) {
    assert.deepEqual(result.manifest.action?.transactionalActions, [
      'transfer_money',
      'delete_account',
    ]);
  }
});

test('full manifest with all three action tiers parses (Tier A reserved for v2)', () => {
  const result = parseConnectorManifest(
    valid({
      surface: {
        type: 'web-iframe',
        entrypoint: 'https://axis-front.onrender.com',
        authBridge: 'sso-jwt',
      },
      action: {
        // Tier A — reserved for v2; manifest accepts it for forward-compat.
        api: { baseUrl: 'https://api.example.com', operations: ['get', 'post'] },
        mcp: { name: 'messaging' },
        harness: { drives: 'surface' },
        transactionalActions: [],
      },
    }),
  );
  assert.ok(result.ok);
  if (result.ok) {
    assert.ok(result.manifest.action?.api);
    assert.ok(result.manifest.action?.mcp);
    assert.ok(result.manifest.action?.harness);
  }
});

test('missing memory.kinds → ZodError', () => {
  const m = valid() as Record<string, unknown>;
  (m.memory as Record<string, unknown>).kinds = [];
  const result = parseConnectorManifest(m);
  assert.equal(result.ok, false);
});

test('missing memory entirely → ZodError', () => {
  const m = valid() as Record<string, unknown>;
  delete m.memory;
  const result = parseConnectorManifest(m);
  assert.equal(result.ok, false);
});

test('promotableKinds ⊆ kinds enforced — extra kind in promotable rejected', () => {
  const result = parseConnectorManifest(
    valid({
      memory: {
        kinds: ['conversation_turn'],
        promotableKinds: ['conversation_summary'], // not in kinds
        driftCheckTools: {},
      },
    }),
  );
  assert.equal(result.ok, false);
  if (!result.ok) {
    const msg = result.error.issues.map((i) => i.message).join(' ');
    assert.match(msg, /promotableKinds/);
  }
});

test('driftCheckTools keys ⊆ kinds enforced — extra key rejected', () => {
  const result = parseConnectorManifest(
    valid({
      memory: {
        kinds: ['conversation_turn'],
        promotableKinds: [],
        driftCheckTools: { deal_won: 'get_deal' }, // 'deal_won' not in kinds
      },
    }),
  );
  assert.equal(result.ok, false);
  if (!result.ok) {
    const msg = result.error.issues.map((i) => i.message).join(' ');
    assert.match(msg, /driftCheckTools/);
  }
});

test('app slug regex — uppercase rejected', () => {
  const result = parseConnectorManifest(valid({ app: 'Messaging' as ConnectorManifest['app'] }));
  assert.equal(result.ok, false);
});

test('app slug regex — leading digit rejected', () => {
  const result = parseConnectorManifest(valid({ app: '1messaging' as ConnectorManifest['app'] }));
  assert.equal(result.ok, false);
});

test('app slug regex — dash-separated valid', () => {
  const result = parseConnectorManifest(valid({ app: 'crm-lite' as ConnectorManifest['app'] }));
  assert.ok(result.ok);
});

test('promotableKinds defaults to [] when omitted', () => {
  const m = valid() as Record<string, unknown>;
  const memory = m.memory as Record<string, unknown>;
  delete memory.promotableKinds;
  delete memory.driftCheckTools;
  const result = parseConnectorManifest(m);
  assert.ok(result.ok);
  if (result.ok) {
    assert.deepEqual(result.manifest.memory.promotableKinds, []);
    assert.deepEqual(result.manifest.memory.driftCheckTools, {});
  }
});

test('transactionalActions defaults to [] when omitted', () => {
  const result = parseConnectorManifest(
    valid({
      action: { mcp: { name: 'messaging' }, transactionalActions: [] },
    }),
  );
  assert.ok(result.ok);
  if (result.ok) {
    assert.deepEqual(result.manifest.action?.transactionalActions, []);
  }
});

test('surface.type=none is valid (no embed)', () => {
  const result = parseConnectorManifest(
    valid({
      surface: { type: 'none', entrypoint: '', authBridge: 'sso-jwt' },
    }),
  );
  assert.ok(result.ok);
});

test('throws-style parse via .parse() also works', () => {
  const m = valid() as Record<string, unknown>;
  delete m.memory;
  assert.throws(() => ConnectorManifestSchema.parse(m));
});
