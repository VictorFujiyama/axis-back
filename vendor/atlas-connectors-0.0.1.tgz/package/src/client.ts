import { signRequest } from './auth.js';
import type { ConnectorEvent } from './envelope.js';

/**
 * [12.2.10] AtlasConnector — the outbox client. Apps construct one per
 * (org, app, secret) tuple at boot and call `.emit(event)` or
 * `.emitBatch(events)` from their domain-event listeners. The SDK
 * handles signing, headers, retry, and (optionally) outbox queueing.
 *
 * Wire shape — POST `<base>/api/connectors/<app>/events` with:
 *   X-Atlas-Signature: t=<unix>,v1=<hex>
 *   X-Atlas-Org-Id:    <uuid>
 *   Content-Type:      application/json
 *
 * Retry policy:
 *  - 5 attempts, exponential backoff (1s → 2s → 4s → 8s → 16s)
 *  - 2xx → success
 *  - 4xx → no retry (signature, schema, or rate-limit problems are
 *    NOT going to fix themselves; surface fast)
 *  - 5xx / timeout / network error → retry
 *  - After 5 failures, throw `ConnectorEmitFailedError` so the source
 *    app's outbox queue can move the job to DLQ
 *
 * `queueAdapter` hook: if provided, `.emit()` defers to the adapter
 * instead of POSTing inline — the source app can wire its own outbox
 * (axis-back has BullMQ; future apps may differ).
 */

export interface AtlasConnectorOpts {
  /** Atlas base URL — e.g. `https://atlas.example.com`. */
  atlasBaseUrl: string;
  /** App slug — must match the `connectors.app` column. */
  app: string;
  /** Atlas org id — baked in at construction so per-call `.emit()` doesn't need to pass it. */
  orgId: string;
  /** Current HMAC secret. Rotation = construct a new connector with the new secret. */
  hmacSecret: string;
  /** Override `fetch` for tests / non-Node runtimes. Defaults to global fetch. */
  fetchImpl?: typeof globalThis.fetch;
  /** Optional outbox queue adapter — see `QueueAdapter` below. */
  queueAdapter?: QueueAdapter;
  /** Override per-request timeout (default 5_000 ms). */
  requestTimeoutMs?: number;
  /** Override max retry attempts (default 5). */
  maxAttempts?: number;
  /** Override base backoff in ms (default 1000 — yields 1/2/4/8/16s). */
  backoffBaseMs?: number;
}

/**
 * Pluggable outbox adapter. When provided, `.emit()` calls
 * `adapter.enqueue(envelope)` and returns immediately; the adapter's
 * worker is expected to call back into `.emitDirect(envelope)` when
 * the queue processes the job. This separation keeps the SDK free of
 * a BullMQ / Redis dependency.
 */
export interface QueueAdapter {
  enqueue: (event: ConnectorEvent) => Promise<void>;
}

export type AttemptResult =
  | { ok: true; status: number }
  | { ok: false; retryable: boolean; status?: number; error?: string };

export class ConnectorEmitFailedError extends Error {
  readonly attempts: number;
  readonly lastStatus: number | undefined;
  readonly lastError: string | undefined;
  constructor(
    attempts: number,
    lastStatus: number | undefined,
    lastError: string | undefined,
  ) {
    super(
      `AtlasConnector.emit failed after ${attempts} attempts ` +
        `(last status=${lastStatus ?? 'n/a'}, error=${lastError ?? 'n/a'})`,
    );
    this.name = 'ConnectorEmitFailedError';
    this.attempts = attempts;
    this.lastStatus = lastStatus;
    this.lastError = lastError;
  }
}

const DEFAULT_TIMEOUT_MS = 5_000;
const DEFAULT_MAX_ATTEMPTS = 5;
const DEFAULT_BACKOFF_BASE_MS = 1_000;
const MAX_BATCH_SIZE = 1_000;

export class AtlasConnector {
  private readonly atlasBaseUrl: string;
  readonly app: string;
  readonly orgId: string;
  private readonly hmacSecret: string;
  private readonly fetchImpl: typeof globalThis.fetch;
  private readonly queueAdapter: QueueAdapter | undefined;
  private readonly requestTimeoutMs: number;
  private readonly maxAttempts: number;
  private readonly backoffBaseMs: number;

  constructor(opts: AtlasConnectorOpts) {
    this.atlasBaseUrl = opts.atlasBaseUrl.replace(/\/$/, '');
    this.app = opts.app;
    this.orgId = opts.orgId;
    this.hmacSecret = opts.hmacSecret;
    this.fetchImpl = opts.fetchImpl ?? globalThis.fetch.bind(globalThis);
    this.queueAdapter = opts.queueAdapter;
    this.requestTimeoutMs = opts.requestTimeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.maxAttempts = opts.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;
    this.backoffBaseMs = opts.backoffBaseMs ?? DEFAULT_BACKOFF_BASE_MS;
  }

  /**
   * Emit one event. If `queueAdapter` is set, defers to the adapter
   * (returns immediately). Otherwise POSTs inline with retry; throws
   * `ConnectorEmitFailedError` if all attempts exhaust.
   */
  async emit(event: ConnectorEvent): Promise<void> {
    if (this.queueAdapter) {
      await this.queueAdapter.enqueue(event);
      return;
    }
    await this.emitDirect(event);
  }

  /**
   * Emit a batch of events in one POST (the receiver at [12.2.15]
   * accepts `{events: ConnectorEvent[]}` for batches). Caps at 1000
   * per call per the spec §12.2.01. Larger batches → split into
   * chunks by the caller.
   */
  async emitBatch(events: ConnectorEvent[]): Promise<void> {
    if (events.length === 0) return;
    if (events.length > MAX_BATCH_SIZE) {
      throw new Error(
        `AtlasConnector.emitBatch: batch size ${events.length} exceeds ${MAX_BATCH_SIZE}; split the batch.`,
      );
    }
    if (this.queueAdapter) {
      // Queue adapter enqueues one-by-one — the adapter chooses whether to
      // batch on the worker side. Keeps the SDK contract simple.
      for (const e of events) await this.queueAdapter.enqueue(e);
      return;
    }
    await this.emitDirect({ events });
  }

  /**
   * Inline POST path — bypasses the queue adapter even if set. Used by
   * the adapter's worker after it dequeues, AND directly by tests.
   * Accepts a single event OR `{events: [...]}` batch payload.
   */
  async emitDirect(payload: ConnectorEvent | { events: ConnectorEvent[] }): Promise<void> {
    const rawBody = JSON.stringify(payload);
    const url = `${this.atlasBaseUrl}/api/connectors/${encodeURIComponent(this.app)}/events`;

    let lastStatus: number | undefined;
    let lastError: string | undefined;

    for (let attempt = 1; attempt <= this.maxAttempts; attempt++) {
      const { signature, orgIdHeader } = signRequest(rawBody, this.orgId, this.hmacSecret);
      const result = await this.attempt(url, rawBody, signature, orgIdHeader);

      if (result.ok) return;

      lastStatus = result.status;
      lastError = result.error;

      // 4xx: signature/schema/rate-limit/etc — fail fast, no retry.
      if (!result.retryable) {
        throw new ConnectorEmitFailedError(attempt, lastStatus, lastError);
      }

      if (attempt < this.maxAttempts) {
        const backoff = this.backoffBaseMs * 2 ** (attempt - 1);
        await sleep(backoff);
      }
    }

    throw new ConnectorEmitFailedError(this.maxAttempts, lastStatus, lastError);
  }

  private async attempt(
    url: string,
    rawBody: string,
    signature: string,
    orgIdHeader: string,
  ): Promise<AttemptResult> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.requestTimeoutMs);
    try {
      const res = await this.fetchImpl(url, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-atlas-signature': signature,
          'x-atlas-org-id': orgIdHeader,
        },
        body: rawBody,
        signal: controller.signal,
      });
      if (res.status >= 200 && res.status < 300) {
        return { ok: true, status: res.status };
      }
      if (res.status >= 400 && res.status < 500) {
        // 4xx — caller's fault, retrying won't help.
        return { ok: false, retryable: false, status: res.status };
      }
      // 5xx and other — retry.
      return { ok: false, retryable: true, status: res.status };
    } catch (err) {
      // Network error / timeout / abort — all retryable.
      return {
        ok: false,
        retryable: true,
        error: (err as Error).message,
      };
    } finally {
      clearTimeout(timeoutId);
    }
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
