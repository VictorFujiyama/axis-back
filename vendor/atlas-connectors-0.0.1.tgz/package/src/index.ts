/**
 * @atlas/connectors — the Connector Bridge SDK.
 *
 * Phase 12.2's "standard bridge" — every connected app (Pillar 1 memory +
 * Pillar 2 action) imports this package. Internal apps in this monorepo
 * import via the workspace alias; external/cross-repo apps install via
 * the distribution channel chosen in [12.2.06b].
 *
 * Surface (filled in by P0b tasks):
 *  - envelope.ts ([12.2.07]) — ConnectorEvent shape + Zod validator
 *  - manifest.ts ([12.2.08]) — ConnectorManifest type + drift-check tool map
 *  - auth.ts ([12.2.09]) — HMAC sign/verify with signed org_id header
 *  - client.ts ([12.2.10]) — AtlasConnector outbox helper
 *  - subscriber.ts ([12.2.53]) — Atlas → app inbound handler
 */
export {
  ConnectorEventSchema,
  ConnectorEventActorSchema,
  ConnectorEventSourceRefSchema,
  ConnectorEventViewableBySchema,
  ConnectorEventActionSchema,
  parseConnectorEvent,
  type ConnectorEvent,
  type ConnectorEventActor,
  type ConnectorEventSourceRef,
  type ConnectorEventViewableBy,
  type ConnectorEventAction,
} from './envelope.js';

export {
  signRequest,
  verifyRequest,
  SIGNATURE_HEADER,
  ORG_ID_HEADER,
  SKEW_TOLERANCE_SEC,
  type SignRequestResult,
  type VerifyRequestResult,
  type VerifyFailReason,
} from './auth.js';

export {
  AtlasConnector,
  ConnectorEmitFailedError,
  type AtlasConnectorOpts,
  type QueueAdapter,
  type AttemptResult,
} from './client.js';

export {
  AtlasSubscriber,
  type AtlasSubscriberOpts,
  type HandleRequestInput,
  type HandleResult,
  type HandleSuccess,
  type HandleFailure,
  type SubscriberFailReason,
} from './subscriber.js';

export {
  ConnectorManifestSchema,
  ConnectorMemorySchema,
  ConnectorActionSchema,
  ConnectorSurfaceSchema,
  ConnectorApiSpecSchema,
  ConnectorMcpServerRefSchema,
  ConnectorHarnessSchema,
  SurfaceTypeSchema,
  SurfaceAuthBridgeSchema,
  parseConnectorManifest,
  type ConnectorManifest,
  type ConnectorMemory,
  type ConnectorAction,
  type ConnectorSurface,
  type ConnectorApiSpec,
  type ConnectorMcpServerRef,
  type ConnectorHarness,
  type SurfaceType,
  type SurfaceAuthBridge,
  type OnEventHook,
  type OnBackfillHook,
  type OnAtlasActivityHook,
  type OnActionRequestHook,
} from './manifest.js';
