import { z } from 'zod';

/**
 * [12.2.07] Connector event envelope — the wire format every connected
 * app speaks. Mirrors Phase 12 spec §12.1.01.
 *
 * Forward-compat invariants:
 *  - `kind` is an open string (not a `z.enum`) — Atlas DROPS unknown kinds
 *    on the worker side rather than rejecting at the envelope. Apps can
 *    ship new kinds without coordinating an SDK release first.
 *  - `viewable_by.scope` is also open — `'participants'|'org'|'users'`
 *    are the spec-named scopes; new scopes parse and the receiver
 *    routes by best-effort.
 *  - `metadata` is a free-form record — never schema-checked, never
 *    full-text indexed; the JSONB on the receiving side is for ad-hoc
 *    filtering, not retrieval.
 *  - `actors[].hints` is a catchall record so apps can attach
 *    correlation signals (atlas_user_id for self-emitted Atlas actions
 *    in [12.2.39], custom attributes, anything) without the schema
 *    fighting them.
 *
 * Strict invariants:
 *  - `event_id` is required and used as the idempotency key alongside
 *    `app` (UNIQUE on `(source_app, event_id)` in memory.events post-
 *    [12.2.11]).
 *  - `org_id` is a UUID — receivers look up the per-(org, app) HMAC
 *    secret by this field; a malformed value fails closed before
 *    the secret lookup runs.
 *  - timestamps require timezone offset — emitting `2026-05-15 10:00:00`
 *    without `Z`/`±hh:mm` is ambiguous; Zod's `datetime({offset:true})`
 *    rejects it.
 */

export const ConnectorEventActionSchema = z.enum(['create', 'update', 'delete']);
export type ConnectorEventAction = z.infer<typeof ConnectorEventActionSchema>;

export const ConnectorEventSourceRefSchema = z.object({
  id: z.string().min(1),
  parent_id: z.string().min(1).optional(),
  url: z.string().url().optional(),
});
export type ConnectorEventSourceRef = z.infer<typeof ConnectorEventSourceRefSchema>;

/**
 * Actor / participant rows. `app_user_id` is required (the source app's
 * own identifier — Atlas's identity resolver in [12.2.18] joins on
 * `(app, app_user_id)`). `hints` carries optional correlation signals
 * (email, phone, atlas_user_id, custom keys); the catchall keeps app-
 * specific extras from being stripped.
 */
export const ConnectorEventActorSchema = z
  .object({
    app_user_id: z.string().min(1),
    role: z.string().min(1).optional(),
    hints: z.record(z.unknown()).optional(),
  })
  .passthrough();
export type ConnectorEventActor = z.infer<typeof ConnectorEventActorSchema>;

/**
 * Visibility scope emitted by the source app — Atlas mirrors this into
 * `memory.events.viewable_by` and enforces on read in `cross_app_search`
 * (Phase 12 §12.9.01).
 *
 * Known scopes: `'participants'` (only actors+participants of this event),
 * `'org'` (anyone in the org), `'users'` (explicit user list in `.users`).
 * Open string for forward-compat — new scopes parse, receiver routes by
 * best-effort.
 */
export const ConnectorEventViewableBySchema = z.object({
  scope: z.string().min(1),
  users: z.array(z.string()).optional(),
});
export type ConnectorEventViewableBy = z.infer<typeof ConnectorEventViewableBySchema>;

export const ConnectorEventSchema = z.object({
  /** Idempotency key — app-generated, UNIQUE per (app, event_id). uuidv7 recommended. */
  event_id: z.string().min(1),
  /** SemVer-ish — `'1.0'` for the spec §12.1.01 envelope. */
  schema_version: z.string().min(1),
  /** ISO 8601 with offset — when the source app emitted (vs `occurred_at` = when the underlying event happened). */
  emitted_at: z.string().datetime({ offset: true }),

  /** App slug (registered in the `connectors` table). */
  app: z.string().min(1),
  /** Source app's own version string — useful for the rollout dashboard. */
  app_version: z.string().min(1).optional(),
  /** Atlas org this event belongs to. UUID validated. */
  org_id: z.string().uuid(),

  /** Open string — Atlas drops unknown kinds (forward-compat per §12.1.02). */
  kind: z.string().min(1),
  action: ConnectorEventActionSchema,

  source_ref: ConnectorEventSourceRefSchema,
  /** When the underlying event happened (vs `emitted_at` = when this envelope was built). */
  occurred_at: z.string().datetime({ offset: true }),

  /** Default `[]` when the source app omits — receiver doesn't need to defensive-check. */
  actors: z.array(ConnectorEventActorSchema).default([]),
  participants: z.array(ConnectorEventActorSchema).default([]),

  /** ≤ ~500 chars in practice — what `cross_app_search` returns as the hit's display string. */
  summary: z.string().min(1),
  /**
   * Optional larger content for embedding. `null` is the explicit
   * "skip embedding for this event" signal per spec §12.1.06 (low-value
   * events: telemetry, system messages, bot replies). `undefined` is
   * "no content distinct from summary" — embed the summary itself.
   */
  embedding_text: z.string().nullable().optional(),

  viewable_by: ConnectorEventViewableBySchema,

  /** Free-form per-app metadata — indexed as JSONB on the receiving side, not full-text searched. */
  metadata: z.record(z.unknown()).default({}),
});

export type ConnectorEvent = z.infer<typeof ConnectorEventSchema>;

/**
 * Non-throwing parse wrapper. Returns a discriminated union so callers
 * can avoid try/catch around `.parse()`. Mirrors the `safeParse` shape
 * but renames `success` → `ok` and gives the parsed event a stable name
 * (`event`) for clearer call-site code.
 */
export type ParseConnectorEventResult =
  | { ok: true; event: ConnectorEvent }
  | { ok: false; error: z.ZodError };

export function parseConnectorEvent(input: unknown): ParseConnectorEventResult {
  const result = ConnectorEventSchema.safeParse(input);
  if (result.success) return { ok: true, event: result.data };
  return { ok: false, error: result.error };
}
