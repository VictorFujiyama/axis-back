import { createHmac, timingSafeEqual } from 'node:crypto';

/**
 * [12.2.09] HMAC sign/verify with a signed `X-Atlas-Org-Id` header.
 *
 * Wire protocol — TWO headers carried on every connector request:
 *
 *   X-Atlas-Signature: t=<unixSec>,v1=<hex>
 *   X-Atlas-Org-Id:    <uuid>
 *
 * The HMAC binds `${t}.${orgId}.${rawBody}` — tampering with body OR
 * org-id header invalidates the signature. The receiver in [12.2.15]
 * reads the org-id header to look up the per-(org, app) secret BEFORE
 * parsing JSON; this is the fix #6 design from the spec review.
 *
 * Dual-secret rotation window: `verifyRequest` accepts either current
 * or previous secret so the rotation can land without dropping in-flight
 * requests signed against the old key. The window expires when the
 * `connectors.hmac_rotates_at + 24h` deadline passes (enforced by the
 * connector lifecycle in [12.2.55]).
 *
 * Skew tolerance: ±300s (5 minutes). Matches Victor's Phase B
 * EVENT_TIMESTAMP_TOLERANCE_S constant.
 */

export const SIGNATURE_HEADER = 'x-atlas-signature' as const;
export const ORG_ID_HEADER = 'x-atlas-org-id' as const;
export const SKEW_TOLERANCE_SEC = 300;

export interface SignRequestResult {
  /** Value for the `X-Atlas-Signature` header. */
  signature: string;
  /** Value for the `X-Atlas-Org-Id` header. */
  orgIdHeader: string;
}

/**
 * Build the two-header signature for a request. `orgId` is bound into
 * the signed payload; tampering with the header invalidates the
 * signature even though it's "just a header."
 *
 * `now` is exposed for tests; production callers omit it.
 */
export function signRequest(
  rawBody: string,
  orgId: string,
  secret: string,
  now: number = Date.now(),
): SignRequestResult {
  const t = Math.floor(now / 1000);
  const sig = computeHmacHex(t, orgId, rawBody, secret);
  return {
    signature: `t=${t},v1=${sig}`,
    orgIdHeader: orgId,
  };
}

export type VerifyRequestResult =
  | { ok: true; orgId: string }
  | { ok: false; reason: VerifyFailReason };

export type VerifyFailReason =
  | 'missing-signature-header'
  | 'missing-org-id-header'
  | 'malformed-signature-header'
  | 'malformed-timestamp'
  | 'timestamp-skew'
  | 'invalid-signature';

/**
 * Verify a signed request. Returns `{ ok: true, orgId }` on success;
 * `{ ok: false, reason }` on any failure. NEVER throws — callers can
 * route the failure reason to a 401 response without try/catch.
 *
 * `prevSecret` enables the rotation window: when set, signatures
 * matching either secret are accepted. Pass undefined when no
 * rotation is in progress.
 */
export function verifyRequest(
  rawBody: string,
  signatureHeader: string | null | undefined,
  orgIdHeader: string | null | undefined,
  currentSecret: string,
  prevSecret: string | undefined = undefined,
  now: number = Date.now(),
): VerifyRequestResult {
  if (!signatureHeader || signatureHeader.length === 0) {
    return { ok: false, reason: 'missing-signature-header' };
  }
  if (!orgIdHeader || orgIdHeader.length === 0) {
    return { ok: false, reason: 'missing-org-id-header' };
  }

  const parts = parseSignatureHeader(signatureHeader);
  if (!parts) return { ok: false, reason: 'malformed-signature-header' };
  const { t, v1 } = parts;
  if (!Number.isFinite(t) || t <= 0) {
    return { ok: false, reason: 'malformed-timestamp' };
  }
  if (Math.abs(now / 1000 - t) > SKEW_TOLERANCE_SEC) {
    return { ok: false, reason: 'timestamp-skew' };
  }

  const expectedCurrent = computeHmacHex(t, orgIdHeader, rawBody, currentSecret);
  if (timingSafeEqualHex(v1, expectedCurrent)) {
    return { ok: true, orgId: orgIdHeader };
  }
  if (prevSecret) {
    const expectedPrev = computeHmacHex(t, orgIdHeader, rawBody, prevSecret);
    if (timingSafeEqualHex(v1, expectedPrev)) {
      return { ok: true, orgId: orgIdHeader };
    }
  }
  return { ok: false, reason: 'invalid-signature' };
}

// ────────────────────────────────────────────────────────────────────────────
// internals

function computeHmacHex(t: number, orgId: string, rawBody: string, secret: string): string {
  return createHmac('sha256', secret).update(`${t}.${orgId}.${rawBody}`).digest('hex');
}

function parseSignatureHeader(header: string): { t: number; v1: string } | null {
  const parts: Record<string, string> = {};
  for (const segment of header.split(',')) {
    const idx = segment.indexOf('=');
    if (idx < 0) continue;
    const k = segment.slice(0, idx).trim();
    const v = segment.slice(idx + 1).trim();
    if (k.length > 0) parts[k] = v;
  }
  const tRaw = parts['t'];
  const v1 = parts['v1'];
  if (!tRaw || !v1) return null;
  const t = Number(tRaw);
  return { t, v1 };
}

/**
 * Timing-safe compare on hex-encoded strings of arbitrary (mismatched)
 * length. timingSafeEqual requires equal-length buffers, so we
 * length-check first.
 */
function timingSafeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  const ba = Buffer.from(a, 'hex');
  const bb = Buffer.from(b, 'hex');
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}
