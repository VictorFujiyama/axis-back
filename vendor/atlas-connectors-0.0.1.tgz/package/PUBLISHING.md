# Publishing `@atlas/connectors` (Phase 12.2 [12.2.06b])

> Decision lock for how external repos (axis-back today, future connectors
> later) consume this package. Decided 2026-05-15. Revisit when the SDK
> stabilizes post-12.2.

## TL;DR — v1 = **vendor via a tarball**

`scripts/dev/vendor-connectors.sh` builds an `npm pack` tarball from this
package. axis-back consumes it via a `file:` dependency:

```json
{
  "dependencies": {
    "@atlas/connectors": "file:./vendor/atlas-connectors-0.0.1.tgz"
  }
}
```

axis-back imports look identical to a published package:

```ts
import { AtlasConnector, ConnectorEventSchema } from '@atlas/connectors';
```

To update axis-back to a new SDK version:

1. Bump `packages/connectors/package.json` `version`
2. From atlas-company-os repo: `bash scripts/dev/vendor-connectors.sh`
3. Copy the resulting tarball into axis-back's `vendor/` dir
4. `cd axis-back && pnpm install`

## Options considered

| Option | Pro | Con | v1 |
|---|---|---|---|
| **(1) GitHub Packages private registry** | Real semver, auto-update via `pnpm update`, CI publish workflow | Package name MUST be `@<github-owner>/...`. `@atlas` org doesn't exist on GitHub; using `@felipebreg/...` forces a rename across the monorepo (breaks the `@atlas/...` convention every other workspace package uses). PAT setup in axis-back. | rejected |
| **(2) Vendor tarball** | Zero registry setup. Keeps `@atlas/connectors` name. Reproducible (the tgz is checked into axis-back's vendor/). | Manual sync on every SDK change. Sync drift if someone forgets to re-run the script. | **chosen** |
| **(3) Git URL with subpath** | No registry setup. Auto-update by bumping the ref. | npm/pnpm don't natively support git URL with subpath — would require a postinstall hack or a Git submodule. Pulls the whole repo for one package. | rejected |

## When to revisit

Migrate to **GitHub Packages** when *any* of these holds:

- A second external consumer beyond axis-back lands (e.g. a partner CRM
  connector) — sync drift across 2+ repos is unmanageable.
- The SDK reaches v0.5+ (stable API) — semver versioning earns its keep.
- We adopt monorepo-wide releases (Changesets) — the publish workflow is
  free at that point.

Migration is mostly mechanical: pick a published name (`@atlas-os/connectors`
under an "atlas-os" org, or `@felipebreg/connectors` under Felipe's account),
update `package.json` + the workspace import paths, set up the publish
workflow. The internal monorepo can keep the `@atlas/connectors` name via
pnpm's package alias (`@atlas/connectors@npm:@atlas-os/connectors`).

## Implementation

`scripts/dev/vendor-connectors.sh` — see that file.

The CI workflow `.github/workflows/publish-connectors.yml` is **NOT
present** in v1 (would add complexity for no v1 benefit). When migrating
to Option (1), that file is the entry point — drafted as a comment block
at the top of this doc when we get there.

## Sync-drift detection (future)

A small CI check could verify axis-back's vendored copy matches the
current `packages/connectors/src/` SHA. Cheap to add when sync drift bites;
deferred until it does.
